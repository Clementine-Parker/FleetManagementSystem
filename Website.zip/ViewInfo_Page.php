<?php
session_start();
if (!isset($_SESSION['user'])) header ('location : index.php');

$user = $_SESSION['user'];
$show = include ('Database/ViewInfo.php');
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Online Fleet Management System</title>
    <link rel="stylesheet" href="Main.css">
    <link rel="stylesheet" href="View.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.35.4/css/bootstrap-dialog.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

</head>
<body>
    <div id="DashMainContainer"> <div class="Dash_Sidebar" id="Sidebar"> 
            <h3 class="Dash_Logo" id="Logo">Dashboard</h3>
            <div class="Dash_User">
                <span>Administrator</span>
            </div>
            <div class="Dash_Sibebar_Menu">
                <ul class="Menu_List">
                    <li class="" id="viewstuff">
                        <a href="ViewInfo_Page.php"> View/Query Details</a>
                    </li>
                    <li class="" id="addveh">
                        <a href="CaptureData_Page.php"> Capture New Vehicle</a>
                    </li>
                    <li class="" id="edit">
                        <a href="Update_Page.php"> Edit/Update Vehicle</a>
                    </li>
                    <li class="" id="logout">
                        <a href="Logout.php"> Logout</a>
                    </li>
                </ul>
                </div>
        </div>
        <div class="Dash_ContContainer" id="ContContainer">
        <?php 
        include ('UI/NavigationBar.html')
        ?>
            <div class="Dash_Content">
                <div class="Dash_View">
                    <div>
                        <h1 class="header"> <i class="fa fa-laptop"></i> View/Query Information</h1>
                    </div>
                    <div class="viewstuff">
                        <table>
                            <thead>
                            <tr>
                                <th>ID</th>
                                <th>Reg Number</th>
                                <th>Manufacturer</th>
                                <th>Car Model</th>
                                <th>Tank Capacity</th>
                                <th>Prev Owner</th>
                                <th>Branch</th>
                                <th>Department</th>
                                <th>Driver</th>
                                <th>Write Off</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php
                                foreach ($show as $index => $user){ ?>
                                
                                <tr>
                                    <td><?= $index + 1 ?></td>
                                    <td class="RegNum"><?= $user ['reg_num'] ?></td>
                                    <td class="Make"><?= $user ['make'] ?></td>
                                    <td class="Model"><?= $user ['model'] ?></td>
                                    <td class="TankCap"><?= $user ['tank_cap'] ?></td>
                                    <td class="PrevOwner"><?= $user ['prev_owner'] ?></td>
                                    <td class="Branch"><?= $user ['branch'] ?></td>
                                    <td class="Depart"><?= $user ['department'] ?></td>
                                    <td class="Driver"><?= $user ['driver'] ?></td>
                                    <td class="Write"><?= $user ['write_off'] ?></td>
                                </tr>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>  
                </div>
            </div>  
        </div>
    </div>
    <script src="query.js">
        toggle.addEventListener( 'click', (event) => {
    event.preventDefault();
    Sidebar.style.width = '10%';
    ContContainer.style.width ='90%';
    Logo.style.fontSize = '20px';
});

    </script>
    
</body>
</html>