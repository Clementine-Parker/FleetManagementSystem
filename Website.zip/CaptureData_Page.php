<?php
session_start();
if (!isset($_SESSION['user'])) header ('location : index.php');
$_SESSION['table'] = 'vehicle';
$user = $_SESSION['user'];
?>
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard - Online Fleet Management System</title>
    <link rel="stylesheet" href="Main.css">
    <link rel="stylesheet" href="Capture.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.35.4/css/bootstrap-dialog.min.css">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">


</head>
<body>
    <div id="DashMainContainer"> <div class="Dash_Sidebar" id="Sidebar"> 
            <h3 class="Dash_Logo" id="Logo">Dashboard</h3>
            <div class="Dash_User">
                <span>Administrator</span>
            </div>
            <div class="Dash_Sibebar_Menu">
            <ul class="Menu_List">
                    <li class="" id="viewstuff">
                        <a href="ViewInfo_Page.php"> View/Query Details</a>
                    </li>
                    <li class="" id="addveh">
                        <a href="CaptureData_Page.php"> Capture New Vehicle</a>
                    </li>
                    <li class="" id="edit">
                        <a href="Update_Page.php"> Edit/Update Vehicle</a>
                    </li>
                    <li class="" id="logout">
                        <a href="Logout.php"> Logout</a>
                    </li>
                </ul>
                </div>
        </div>
        <div class="Dash_ContContainer" id="ContContainer">
       
            <div class="Dash_Content">
                <div class="Dash_View">
                    <div class="viewstuff">
                    <div id="formContainer">
                    <form action="database/vehicleadd.php" method="POST" class="appForm">
                    <div class="FormContainer">
                    <label for="reg_num">Registration Number</label>
                    <input type="text" class="formInput" id="reg_num" name="reg_num"/>
                    </div>
                    <div class="FormContainer">
                    <label for="make">Make/Manufacturer</label>
                    <input type="text" class="formInput" id="make" name="make"/>
                    </div>
                    <div class="FormContainer">
                    <label for="model">Model</label>
                    <input type="text" class="formInput" id="model" name="model"/>
                    </div>
                    <div class="FormContainer">
                    <label for="tank_cap">Tank Capacity</label>
                    <input type="text" class="formInput" id="tank_cap" name="tank_cap"/>
                    </div>
                    <div class="FormContainer">
                    <label for="prev_owner">Previous Owner</label>
                    <input type="text" class="formInput" id="prev_owner" name="prev_owner"/>
                    </div>
                    <div class="FormContainer">
                    <label for="branch">Designated Branch</label>
                    <input type="text" class="formInput" id="branch" name="branch"/>
                    </div>
                    <div class="FormContainer">
                    <label for="department">Department</label>
                    <input type="text" class="formInput" id="department" name="department"/>
                    </div>
                    <div class="FormContainer">
                    <label for="driver">Driver</label>
                    <input type="text" class="formInput" id="driver" name="driver"/>
                    </div>
                    <button type="submit" class="btnAdd">Add Vehicle</button>
                    </form>
                    <?php
                    if (isset($_SESSION['response'])) { 
                        $response = $_SESSION['response']['message'];
                        $is_success = $_SESSION['response']['success'];
                        ?>
                    <div class="Response">
                        <p class="<?= $is_success ? 'responseMessage__success' : 'responseMessage__error' ?>">
                        <?= $response ?>
                    </p>
                    </div>
                    <?php unset($_SESSION['response']);} ?>
                    </div>
                    </div>  
                </div>
            </div>  
        </div>
    </div>
    <script src="query.js">
        toggle.addEventListener( 'click', (event) => {
    event.preventDefault();
    Sidebar.style.width = '10%';
    ContContainer.style.width ='90%';
    Logo.style.fontSize = '20px';
});

    </script>
    <script src="Javascript/jQuery.js"></script>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap3-dialog/1.35.4/css/bootstrap-dialog.js"></script>
    
</body>
</html>