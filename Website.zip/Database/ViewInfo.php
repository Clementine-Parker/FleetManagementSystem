<?php
    include ('DatabaseConn.php');
     $stmt = $conn->prepare("SELECT * FROM `management`.`vehicle`");
     $stmt->execute();
     $result = $stmt->setFetchMode(PDO::FETCH_ASSOC);

     return $stmt->fetchAll();